{include file="sections/header.tpl"}

<form class="form-horizontal" method="post" role="form" action="{$_url}paymentgateway/ipaymu">
    <div class="row">
        <div class="col-sm-12 col-md-12">
            <div class="panel panel-primary panel-hovered panel-stacked mb30">
                <div class="panel-heading">iPaymu Payment Gateway</div>
                <div class="panel-body">
                    <div class="alert alert-info">
                        Belum memiliki akun iPaymu?
                        <a id="ipaymu-register-button" href="https://my.ipaymu.com/register/ref/ardian08221" target="_blank" rel="noopener noreferrer" class="btn btn-success btn-sm" style="margin-left:10px">
                            <i class="glyphicon glyphicon-user"></i> Daftar iPaymu
                        </a>
                    </div>

                    <div class="form-group">
                        <label class="col-md-3 control-label">Mode</label>
                        <div class="col-md-6">
                            <select class="form-control" name="ipaymu_environment">
                                <option value="sandbox" {if empty($_c['ipaymu_environment']) || $_c['ipaymu_environment'] == 'sandbox'}selected{/if}>Sandbox / Pengujian</option>
                                <option value="production" {if $_c['ipaymu_environment'] == 'production'}selected{/if}>Production / Live</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-3 control-label">Virtual Account (VA)</label>
                        <div class="col-md-6">
                            <input type="text" class="form-control" name="ipaymu_va" value="{$_c['ipaymu_va']}" required autocomplete="off" placeholder="Masukkan nomor VA merchant">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-3 control-label">API Key</label>
                        <div class="col-md-6">
                            <input type="password" class="form-control" name="ipaymu_api_key" autocomplete="new-password" placeholder="Kosongkan jika tidak diubah">
                            <span class="help-block">API Key tidak pernah ditampilkan kembali pada formulir ini.</span>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-3 control-label">Biaya transaksi ditanggung</label>
                        <div class="col-md-6">
                            <select class="form-control" name="ipaymu_fee_direction">
                                <option value="MERCHANT" {if empty($_c['ipaymu_fee_direction']) || $_c['ipaymu_fee_direction'] == 'MERCHANT'}selected{/if}>Merchant</option>
                                <option value="BUYER" {if $_c['ipaymu_fee_direction'] == 'BUYER'}selected{/if}>Pelanggan</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-3 control-label">Masa berlaku pembayaran</label>
                        <div class="col-md-6">
                            <div class="input-group">
                                <input type="number" min="1" max="24" class="form-control" name="ipaymu_expiry_hours" value="{if !empty($_c['ipaymu_expiry_hours'])}{$_c['ipaymu_expiry_hours']}{else}24{/if}" required>
                                <span class="input-group-addon">jam</span>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-3 control-label">URL Callback</label>
                        <div class="col-md-6">
                            <input type="text" readonly class="form-control" onclick="this.select()" value="{$_url}callback/ipaymu">
                            <span class="help-block">URL ini dikirim otomatis saat membuat transaksi.</span>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-lg-offset-3 col-lg-9">
                            <button class="btn btn-primary waves-effect waves-light" type="submit">
                                <i class="glyphicon glyphicon-floppy-disk"></i> {Lang::T('Save Change')}
                            </button>
                        </div>
                    </div>

                    <h4>Hotspot Walled Garden</h4>
                    <pre>/ip hotspot walled-garden
add dst-host=ipaymu.com
add dst-host=*.ipaymu.com</pre>
                    <small class="form-text text-muted">Aktifkan Telegram Bot PHPNuxBill untuk menerima notifikasi kesalahan transaksi.</small>
                </div>
            </div>
        </div>
    </div>
</form>

{include file="sections/footer.tpl"}
