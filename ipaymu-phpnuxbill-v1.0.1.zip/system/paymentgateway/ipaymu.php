<?php

/**
 * iPaymu Payment Gateway for PHPNuxBill
 * API documentation: https://docs.ipaymu.com/id/docs
 */

function ipaymu_validate_config()
{
    global $config;
    ipaymu_enforce_referral_integrity();
    if (empty($config['ipaymu_va']) || empty($config['ipaymu_api_key'])) {
        Message::sendTelegram('iPaymu payment gateway belum dikonfigurasi.');
        r2(U . 'order/package', 'w', Lang::T('Admin has not yet setup iPaymu payment gateway, please tell admin'));
    }
}

function ipaymu_show_config()
{
    global $ui;
    $ui->assign('_title', 'iPaymu - Payment Gateway');
    $ui->display('ipaymu.tpl');
}

function ipaymu_save_config()
{
    global $admin, $config;

    $values = [
        'ipaymu_va' => trim((string) _post('ipaymu_va')),
        'ipaymu_environment' => _post('ipaymu_environment') === 'production' ? 'production' : 'sandbox',
        'ipaymu_fee_direction' => _post('ipaymu_fee_direction') === 'BUYER' ? 'BUYER' : 'MERCHANT',
        'ipaymu_expiry_hours' => max(1, min(24, (int) _post('ipaymu_expiry_hours'))),
    ];

    $apiKey = trim((string) _post('ipaymu_api_key'));
    if ($apiKey !== '') {
        $values['ipaymu_api_key'] = $apiKey;
    } elseif (empty($config['ipaymu_api_key'])) {
        $values['ipaymu_api_key'] = '';
    }

    foreach ($values as $setting => $value) {
        ipaymu_save_setting($setting, $value);
    }

    _log('[' . $admin['username'] . ']: iPaymu ' . Lang::T('Settings_Saved_Successfully'), 'Admin', $admin['id']);
    r2(U . 'paymentgateway/ipaymu', 's', Lang::T('Settings_Saved_Successfully'));
}

function ipaymu_save_setting($setting, $value)
{
    $row = ORM::for_table('tbl_appconfig')->where('setting', $setting)->find_one();
    if (!$row) {
        $row = ORM::for_table('tbl_appconfig')->create();
        $row->setting = $setting;
    }
    $row->value = (string) $value;
    $row->save();
}

function ipaymu_referral_url()
{
    return 'https://my.ipaymu.com/register/ref/ardian08221';
}

function ipaymu_referral_link_is_intact()
{
    $template = __DIR__ . '/ui/ipaymu.tpl';
    if (!is_readable($template)) {
        return false;
    }

    $contents = file_get_contents($template);
    if ($contents === false) {
        return false;
    }

    return ipaymu_referral_link_matches($contents);
}

function ipaymu_referral_link_matches($contents)
{
    if (!preg_match_all('/<a\b[^>]*>/i', (string) $contents, $anchors)) {
        return false;
    }

    foreach ($anchors[0] as $anchor) {
        if (!preg_match('/\bid\s*=\s*(["\'])ipaymu-register-button\1/i', $anchor)) {
            continue;
        }
        if (!preg_match('/\bhref\s*=\s*(["\'])(.*?)\1/i', $anchor, $href)) {
            return false;
        }
        $actual = html_entity_decode(trim($href[2]), ENT_QUOTES, 'UTF-8');
        return hash_equals(ipaymu_referral_url(), $actual);
    }

    return false;
}

function ipaymu_enforce_referral_integrity()
{
    if (ipaymu_referral_link_is_intact()) {
        return;
    }

    _log('iPaymu dinonaktifkan: tombol atau link registrasi plugin telah diubah/dihapus.');
    if (class_exists('Message')) {
        Message::sendTelegram('iPaymu dinonaktifkan karena tombol/link Daftar iPaymu diubah atau dihapus. Pulihkan system/paymentgateway/ui/ipaymu.tpl.');
    }
    r2(
        U . 'order/package',
        'e',
        'Payment gateway iPaymu dinonaktifkan karena pemeriksaan integritas plugin gagal. Hubungi administrator.'
    );
}

function ipaymu_create_transaction($trx, $user)
{
    global $config;

    // Pemeriksaan kedua mengamankan instalasi PHPNuxBill yang melewati
    // fungsi validasi gateway pada alur checkout kustom.
    ipaymu_enforce_referral_integrity();

    $referenceId = 'PNB-' . (int) $trx['id'] . '-' . time();
    $host = isset($_SERVER['HTTP_HOST']) ? preg_replace('/[^a-z0-9.\-]/i', '', $_SERVER['HTTP_HOST']) : 'localhost';
    $email = !empty($user['email']) ? $user['email'] : $user['username'] . '@' . $host;
    $phone = !empty($user['phonenumber']) ? preg_replace('/[^0-9+]/', '', $user['phonenumber']) : '080000000000';
    $expiry = !empty($config['ipaymu_expiry_hours']) ? max(1, min(24, (int) $config['ipaymu_expiry_hours'])) : 24;

    $payload = [
        'product' => [(string) $trx['plan_name']],
        'qty' => [1],
        'price' => [(int) round((float) $trx['price'])],
        'returnUrl' => U . 'order/view/' . $trx['id'] . '/check',
        'cancelUrl' => U . 'order/view/' . $trx['id'],
        'notifyUrl' => U . 'callback/ipaymu',
        'referenceId' => $referenceId,
        'buyerName' => (string) $user['fullname'],
        'buyerEmail' => (string) $email,
        'buyerPhone' => (string) $phone,
        'comments' => 'Pembayaran ' . (string) $trx['plan_name'],
        'feeDirection' => !empty($config['ipaymu_fee_direction']) ? $config['ipaymu_fee_direction'] : 'MERCHANT',
        'expired' => $expiry,
        'expiredType' => 'HOURS',
    ];

    $result = ipaymu_api_request('/api/v2/payment', $payload);
    $data = isset($result['Data']) && is_array($result['Data']) ? $result['Data'] : [];
    if (empty($data['Url'])) {
        _log('iPaymu create transaction failed: ' . json_encode($result));
        Message::sendTelegram("iPaymu payment failed\n\n" . json_encode($result, JSON_PRETTY_PRINT));
        r2(U . 'order/package', 'e', Lang::T('Failed to create transaction.'));
    }

    $row = ORM::for_table('tbl_payment_gateway')->find_one($trx['id']);
    $row->gateway_trx_id = $referenceId;
    $row->pg_url_payment = $data['Url'];
    $row->payment_method = 'redirect';
    $row->payment_channel = 'iPaymu';
    $row->pg_request = json_encode(['request' => $payload, 'response' => $result]);
    $row->expired_date = !empty($data['Expired']) ? date('Y-m-d H:i:s', strtotime($data['Expired'])) : date('Y-m-d H:i:s', strtotime('+' . $expiry . ' hours'));
    $row->save();

    r2($data['Url'], 's', Lang::T('Create Transaction Success'));
}

function ipaymu_get_status($trx, $user)
{
    $stored = json_decode((string) $trx['pg_request'], true);
    $transactionId = $stored['response']['Data']['TransactionId'] ?? null;
    if (empty($transactionId)) {
        r2(U . 'order/view/' . $trx['id'], 'w', Lang::T('Transaction still unpaid.'));
    }

    $result = ipaymu_api_request('/api/v2/transaction', ['transactionId' => $transactionId]);
    $data = isset($result['Data']) && is_array($result['Data']) ? $result['Data'] : [];
    $statusCode = isset($data['Status']) ? (int) $data['Status'] : (isset($result['Status']) ? (int) $result['Status'] : 0);

    if ($statusCode === 1 && (int) $trx['status'] !== 2) {
        $amount = $data['Amount'] ?? $data['Total'] ?? $trx['price'];
        if (!Billing::finalizeGateway($trx['id'], $user, 'iPaymu', $result, [
            'expected_amount' => $amount,
            'payment_method' => $data['PaymentMethod'] ?? 'iPaymu',
        ])) {
            r2(U . 'order/view/' . $trx['id'], 'd', Lang::T('Failed to activate your Package, try again later.'));
        }
        r2(U . 'order/view/' . $trx['id'], 's', Lang::T('Transaction has been paid.'));
    }

    if (in_array($statusCode, [-1, -2], true)) {
        Billing::markGatewayFailed($trx['id'], $result);
        r2(U . 'order/view/' . $trx['id'], 'd', Lang::T('Transaction expired or Failed.'));
    }

    if ((int) $trx['status'] === 2) {
        r2(U . 'order/view/' . $trx['id'], 's', Lang::T('Transaction has been paid.'));
    }
    r2(U . 'order/view/' . $trx['id'], 'w', Lang::T('Transaction still unpaid.'));
}

function ipaymu_payment_notification()
{
    global $config;

    $raw = file_get_contents('php://input');
    $contentType = $_SERVER['CONTENT_TYPE'] ?? '';
    if (stripos($contentType, 'application/json') !== false) {
        $payload = json_decode($raw, true);
    } else {
        $payload = $_POST;
        if (empty($payload)) {
            parse_str($raw, $payload);
        }
    }

    if (!is_array($payload) || empty($payload)) {
        ipaymu_callback_response(400, 'Payload tidak valid');
    }

    $signature = $_SERVER['HTTP_X_SIGNATURE'] ?? '';
    if ($signature === '' && function_exists('getallheaders')) {
        foreach (getallheaders() as $name => $value) {
            if (strcasecmp($name, 'X-Signature') === 0) {
                $signature = $value;
                break;
            }
        }
    }

    if (empty($config['ipaymu_va']) || !ipaymu_verify_callback_signature($payload, $signature, $config['ipaymu_va'])) {
        _log('iPaymu callback rejected: invalid signature');
        ipaymu_callback_response(403, 'Signature tidak valid');
    }

    $referenceId = $payload['reference_id'] ?? $payload['referenceId'] ?? '';
    if ($referenceId === '') {
        ipaymu_callback_response(200, 'Reference kosong');
    }

    $trx = ORM::for_table('tbl_payment_gateway')
        ->where('gateway', 'ipaymu')
        ->where('gateway_trx_id', (string) $referenceId)
        ->order_by_desc('id')
        ->find_one();
    if (!$trx) {
        _log('iPaymu callback transaction not found: ' . $referenceId);
        ipaymu_callback_response(200, 'Transaksi tidak ditemukan');
    }

    if ((int) $trx['status'] === 2 || !empty($trx['trx_invoice'])) {
        ipaymu_callback_response(200, 'OK');
    }

    $statusCode = isset($payload['status_code']) ? (int) $payload['status_code'] : 0;
    $transactionStatus = isset($payload['transaction_status_code']) ? (int) $payload['transaction_status_code'] : 0;
    $isPaid = $statusCode === 1 && in_array($transactionStatus, [1, 6], true);

    if ($isPaid) {
        $amount = $payload['amount'] ?? $payload['total'] ?? null;
        if ($amount === null || abs((float) $amount - (float) $trx['price']) > 0.01) {
            _log('iPaymu callback amount mismatch for #' . $trx['id']);
            ipaymu_callback_response(200, 'Nominal tidak cocok');
        }

        $user = !empty($trx['user_id'])
            ? ORM::for_table('tbl_customers')->find_one((int) $trx['user_id'])
            : ORM::for_table('tbl_customers')->where('username', $trx['username'])->find_one();
        if (!$user) {
            _log('iPaymu callback user not found for #' . $trx['id']);
            ipaymu_callback_response(200, 'Pelanggan tidak ditemukan');
        }

        $paidDate = !empty($payload['paid_at']) && strtotime($payload['paid_at'])
            ? date('Y-m-d H:i:s', strtotime($payload['paid_at']))
            : date('Y-m-d H:i:s');
        $channel = $payload['payment_channel'] ?? $payload['payment_method'] ?? 'iPaymu';
        $ok = Billing::finalizeGateway($trx['id'], $user, (string) $channel, $payload, [
            'expected_amount' => $amount,
            'payment_method' => $payload['payment_method'] ?? 'iPaymu',
            'paid_date' => $paidDate,
        ]);
        ipaymu_callback_response(200, $ok ? 'OK' : 'Aktivasi belum berhasil');
    }

    if ($statusCode === -2) {
        Billing::markGatewayFailed($trx['id'], $payload);
    }
    ipaymu_callback_response(200, 'OK');
}

function ipaymu_verify_callback_signature(array $payload, $signature, $va)
{
    if ($signature === '' || $va === '') {
        return false;
    }
    unset($payload['signature']);
    foreach (['trx_id', 'status_code', 'transaction_status_code', 'paid_off'] as $field) {
        if (array_key_exists($field, $payload)) {
            $payload[$field] = (int) $payload[$field];
        }
    }
    if (array_key_exists('is_escrow', $payload)) {
        $payload['is_escrow'] = filter_var($payload['is_escrow'], FILTER_VALIDATE_BOOLEAN);
    }
    if (!array_key_exists('additional_info', $payload) || $payload['additional_info'] === '' || $payload['additional_info'] === '[]') {
        $payload['additional_info'] = [];
    } elseif (is_string($payload['additional_info'])) {
        $decoded = json_decode($payload['additional_info'], true);
        if (is_array($decoded)) {
            $payload['additional_info'] = $decoded;
        }
    }
    ksort($payload, SORT_STRING);
    $expected = hash_hmac('sha256', json_encode($payload), (string) $va);
    return hash_equals(strtolower($expected), strtolower(trim((string) $signature)));
}

function ipaymu_api_request($path, array $payload)
{
    global $config;

    $environment = !empty($config['ipaymu_environment']) ? $config['ipaymu_environment'] : 'sandbox';
    $baseUrl = $environment === 'production' ? 'https://my.ipaymu.com' : 'https://sandbox.ipaymu.com';
    $va = (string) ($config['ipaymu_va'] ?? '');
    $apiKey = (string) ($config['ipaymu_api_key'] ?? '');
    $body = json_encode($payload);
    $timestamp = date('YmdHis');
    $bodyHash = strtolower(hash('sha256', $body));
    $stringToSign = 'POST:' . $va . ':' . $bodyHash . ':' . $apiKey;
    $signature = hash_hmac('sha256', $stringToSign, $apiKey);

    $ch = curl_init($baseUrl . $path);
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CONNECTTIMEOUT => 15,
        CURLOPT_TIMEOUT => 45,
        CURLOPT_HTTPHEADER => [
            'Accept: application/json',
            'Content-Type: application/json',
            'va: ' . $va,
            'signature: ' . $signature,
            'timestamp: ' . $timestamp,
        ],
        CURLOPT_POSTFIELDS => $body,
    ]);
    $response = curl_exec($ch);
    $httpCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);

    if ($response === false || $error !== '') {
        return ['Status' => 500, 'Message' => 'Koneksi iPaymu gagal: ' . $error];
    }
    $decoded = json_decode($response, true);
    if (!is_array($decoded)) {
        return ['Status' => $httpCode, 'Message' => 'Respons iPaymu tidak valid', 'Raw' => substr($response, 0, 500)];
    }
    $decoded['_http_code'] = $httpCode;
    return $decoded;
}

function ipaymu_callback_response($status, $message)
{
    http_response_code((int) $status);
    header('Content-Type: application/json');
    echo json_encode(['success' => (int) $status === 200, 'message' => $message]);
    exit;
}
